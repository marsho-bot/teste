"use client";

import React from "react";
import { Terminal, Github, Twitter, Linkedin, ArrowUpRight } from "lucide-react";

const FOOTER_LINKS = {
  Serviços: [
    { label: "SaaS & Plataformas", href: "#services" },
    { label: "Web Apps", href: "#services" },
    { label: "Mobile", href: "#services" },
    { label: "AI & LLMs", href: "#services" },
    { label: "DevOps", href: "#services" },
  ],
  Empresa: [
    { label: "Sobre nós", href: "#about" },
    { label: "Pipeline", href: "#pipeline" },
    { label: "Tech Stack", href: "#stack" },
    { label: "Blog", href: "/blog" },
    { label: "Carreiras", href: "/careers" },
  ],
  Legal: [
    { label: "Privacidade", href: "/privacy" },
    { label: "Termos de Uso", href: "/terms" },
    { label: "Cookies", href: "/cookies" },
  ],
};

const SOCIAL_LINKS = [
  { icon: Github, label: "GitHub", href: "https://github.com/nexuslabs" },
  { icon: Twitter, label: "Twitter / X", href: "https://twitter.com/nexuslabs" },
  { icon: Linkedin, label: "LinkedIn", href: "https://linkedin.com/company/nexuslabs" },
];

export default function Footer() {
  return (
    <footer
      role="contentinfo"
      className="border-t border-border bg-surface-1"
      aria-label="Rodapé do site"
    >
      {/* CTA Band */}
      <div className="border-b border-border">
        <div className="container-main py-12 flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="text-center sm:text-left">
            <h3 className="text-xl font-semibold mb-1">
              Pronto para começar?
            </h3>
            <p className="text-muted text-sm">
              Fale com nossa equipe e receba uma análise técnica gratuita.
            </p>
          </div>
          <a
            href="#contact"
            className="btn-primary px-6 py-3.5 text-base min-h-[52px] flex-shrink-0"
            aria-label="Iniciar projeto com Nexus Labs"
          >
            Iniciar Projeto
            <ArrowUpRight size={16} aria-hidden="true" />
          </a>
        </div>
      </div>

      {/* Main footer */}
      <div className="container-main py-14">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 lg:gap-12">
          {/* Brand col */}
          <div className="col-span-2 md:col-span-1 flex flex-col gap-5">
            <a
              href="/"
              className="flex items-center gap-2.5 w-fit min-h-[auto] min-w-[auto] !justify-start"
              aria-label="Nexus Labs - Página inicial"
            >
              <div
                className="flex items-center justify-center w-8 h-8 rounded-lg bg-accent/10 border border-accent/30"
                aria-hidden="true"
              >
                <Terminal size={16} className="text-accent" />
              </div>
              <span className="font-mono text-sm font-semibold tracking-tight">
                <span className="text-foreground">nexus</span>
                <span className="text-accent">.</span>
                <span className="text-muted">labs</span>
              </span>
            </a>
            <p className="text-sm text-muted leading-relaxed max-w-[200px]">
              Engenharia de Software de Elite para o Mercado Global.
            </p>
            {/* Social */}
            <div className="flex gap-2" role="list" aria-label="Redes sociais">
              {SOCIAL_LINKS.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center w-9 h-9 rounded-xl border border-border bg-surface-2 text-muted hover:text-foreground hover:border-accent/40 transition-all duration-200 min-h-[44px] min-w-[44px]"
                  aria-label={social.label}
                  role="listitem"
                >
                  <social.icon size={14} aria-hidden="true" />
                </a>
              ))}
            </div>
          </div>

          {/* Link columns */}
          {Object.entries(FOOTER_LINKS).map(([title, links]) => (
            <nav key={title} aria-label={`Links de ${title}`}>
              <h4 className="text-xs font-mono font-semibold text-muted uppercase tracking-widest mb-4">
                {title}
              </h4>
              <ul className="flex flex-col gap-2.5" role="list">
                {links.map((link) => (
                  <li key={link.label} role="listitem">
                    <a
                      href={link.href}
                      className="text-sm text-muted hover:text-foreground transition-colors duration-200 min-h-[auto] min-w-[auto] !justify-start"
                    >
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </nav>
          ))}
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-border">
        <div className="container-main py-5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs text-muted font-mono">
            © {new Date().getFullYear()} Nexus Labs. Todos os direitos reservados.
          </p>
          <div className="flex items-center gap-1.5">
            <div className="glow-dot w-1.5 h-1.5" aria-hidden="true" />
            <span className="text-xs font-mono text-muted">
              Status: <span className="text-green-400">All systems operational</span>
            </span>
          </div>
        </div>
      </div>
    </footer>
  );
}
