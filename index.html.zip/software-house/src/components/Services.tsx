"use client";

import React, { useCallback, useState } from "react";
import {
  Globe,
  Smartphone,
  Brain,
  Container,
  Plug,
  Palette,
  ShieldCheck,
  Layers,
  ArrowUpRight,
} from "lucide-react";

interface Service {
  id: string;
  icon: React.ElementType;
  title: string;
  description: string;
  tags: string[];
  size: "large" | "medium" | "small";
  accent: string;
  accentBg: string;
}

const SERVICES: Service[] = [
  {
    id: "saas",
    icon: Layers,
    title: "SaaS & Plataformas",
    description:
      "Arquitetamos e construímos produtos SaaS multi-tenant do zero. Billing, onboarding, RBAC, analytics — tudo integrado e escalável desde o primeiro commit.",
    tags: ["Multi-tenant", "Stripe", "Auth", "Analytics"],
    size: "large",
    accent: "#0070f3",
    accentBg: "rgba(0,112,243,0.08)",
  },
  {
    id: "web",
    icon: Globe,
    title: "Web Apps",
    description:
      "Next.js, React, performance 100/100 no Lighthouse. Interfaces que convertem.",
    tags: ["Next.js", "React", "Edge"],
    size: "medium",
    accent: "#7c3aed",
    accentBg: "rgba(124,58,237,0.08)",
  },
  {
    id: "mobile",
    icon: Smartphone,
    title: "Mobile Nativo",
    description:
      "iOS e Android com React Native. Uma base, dois ecossistemas, zero compromisso de experiência.",
    tags: ["React Native", "Expo", "iOS", "Android"],
    size: "medium",
    accent: "#059669",
    accentBg: "rgba(5,150,105,0.08)",
  },
  {
    id: "ai",
    icon: Brain,
    title: "AI & LLM Integration",
    description:
      "RAG pipelines, fine-tuning, agentes autônomos. Levamos IA para produção com observabilidade e custo controlado.",
    tags: ["OpenAI", "RAG", "LangChain", "Vector DB"],
    size: "large",
    accent: "#d97706",
    accentBg: "rgba(217,119,6,0.08)",
  },
  {
    id: "devops",
    icon: Container,
    title: "DevOps & Cloud",
    description:
      "Infraestrutura como código, CI/CD, Kubernetes. Zero downtime garantido.",
    tags: ["AWS", "K8s", "Terraform", "GitHub Actions"],
    size: "small",
    accent: "#0891b2",
    accentBg: "rgba(8,145,178,0.08)",
  },
  {
    id: "api",
    icon: Plug,
    title: "APIs & Backend",
    description:
      "REST e GraphQL com Node.js, Go ou Rust. Performance sub-5ms, cobertura de testes 90%+.",
    tags: ["Node.js", "Go", "Rust", "GraphQL"],
    size: "small",
    accent: "#dc2626",
    accentBg: "rgba(220,38,38,0.08)",
  },
  {
    id: "design",
    icon: Palette,
    title: "Design System",
    description:
      "Design tokens, Storybook, componentes acessíveis. UX que encanta e converte.",
    tags: ["Figma", "Storybook", "WCAG 2.1"],
    size: "small",
    accent: "#c026d3",
    accentBg: "rgba(192,38,211,0.08)",
  },
  {
    id: "security",
    icon: ShieldCheck,
    title: "Security & Compliance",
    description:
      "Pen-testing, OWASP, SOC 2. Segurança integrada desde a arquitetura, não adicionada depois.",
    tags: ["OWASP", "SOC 2", "GDPR", "Pen-test"],
    size: "small",
    accent: "#16a34a",
    accentBg: "rgba(22,163,74,0.08)",
  },
];

interface ServiceCardProps {
  service: Service;
}

function ServiceCard({ service }: ServiceCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const Icon = service.icon;

  const handleMouseEnter = useCallback(() => setIsHovered(true), []);
  const handleMouseLeave = useCallback(() => setIsHovered(false), []);

  const sizeClasses = {
    large: "md:col-span-2 md:row-span-2",
    medium: "md:col-span-1 md:row-span-2",
    small: "md:col-span-1 md:row-span-1",
  };

  return (
    <article
      className={[
        "group relative rounded-2xl border border-border bg-surface-1 overflow-hidden",
        "transition-all duration-300 cursor-default",
        "hover:border-[--card-accent] hover:shadow-[0_0_30px_var(--card-accent-bg)]",
        sizeClasses[service.size],
        "p-6",
        service.size === "large" ? "flex flex-col justify-between" : "",
      ].join(" ")}
      style={
        {
          "--card-accent": service.accent,
          "--card-accent-bg": service.accentBg,
        } as React.CSSProperties
      }
      onMouseEnter={handleMouseEnter}
      onMouseLeave={handleMouseLeave}
      aria-label={`Serviço: ${service.title}`}
    >
      {/* Background glow on hover */}
      <div
        className="absolute inset-0 transition-opacity duration-300 opacity-0 group-hover:opacity-100"
        style={{ background: service.accentBg }}
        aria-hidden="true"
      />

      {/* Scan line effect */}
      {isHovered && (
        <div
          className="absolute inset-0 overflow-hidden pointer-events-none"
          aria-hidden="true"
        >
          <div
            className="absolute left-0 right-0 h-px animate-scan-line"
            style={{
              background: `linear-gradient(90deg, transparent, ${service.accent}40, transparent)`,
            }}
          />
        </div>
      )}

      <div className="relative z-10 flex flex-col gap-4 h-full">
        {/* Icon + Arrow */}
        <div className="flex items-start justify-between">
          <div
            className="flex items-center justify-center w-10 h-10 rounded-xl border transition-all duration-300 group-hover:scale-110"
            style={{
              backgroundColor: `${service.accent}15`,
              borderColor: `${service.accent}30`,
            }}
            aria-hidden="true"
          >
            <Icon size={18} style={{ color: service.accent }} />
          </div>
          <div
            className="opacity-0 group-hover:opacity-100 transition-all duration-200 translate-x-1 group-hover:translate-x-0 -translate-y-1 group-hover:translate-y-0"
            aria-hidden="true"
          >
            <ArrowUpRight size={14} style={{ color: service.accent }} />
          </div>
        </div>

        {/* Content */}
        <div className="flex flex-col gap-2 flex-1">
          <h3 className="text-base font-semibold text-foreground leading-snug">
            {service.title}
          </h3>
          <p
            className={[
              "text-sm text-muted leading-relaxed",
              service.size === "small" ? "line-clamp-3" : "",
            ].join(" ")}
          >
            {service.description}
          </p>
        </div>

        {/* Tags */}
        <div className="flex flex-wrap gap-1.5" role="list" aria-label="Tecnologias">
          {service.tags.map((tag) => (
            <span
              key={tag}
              className="px-2 py-0.5 rounded-full text-xs font-mono border transition-all duration-200 group-hover:border-[--card-accent] group-hover:text-[--card-accent]"
              style={
                {
                  backgroundColor: `${service.accent}08`,
                  borderColor: `${service.accent}20`,
                  color: "#6b7280",
                } as React.CSSProperties
              }
              role="listitem"
            >
              {tag}
            </span>
          ))}
        </div>
      </div>
    </article>
  );
}

export default function Services() {
  return (
    <section
      id="services"
      className="section-padding"
      aria-labelledby="services-heading"
    >
      <div className="container-main">
        {/* Header */}
        <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-6 mb-12">
          <div className="flex flex-col gap-3">
            <span className="tag" aria-hidden="true">
              Serviços
            </span>
            <h2
              id="services-heading"
              className="text-3xl sm:text-4xl lg:text-5xl font-semibold leading-tight tracking-tight"
            >
              O que
              <br />
              <span className="text-gradient">construímos</span>
            </h2>
          </div>
          <p className="text-muted text-base leading-relaxed max-w-sm sm:text-right">
            Da ideia ao produto em produção. Engenharia de ponta a ponta com
            foco em performance e escalabilidade.
          </p>
        </div>

        {/* Bento Grid */}
        <div
          className="grid grid-cols-1 md:grid-cols-3 md:auto-rows-[200px] gap-4"
          role="list"
          aria-label="Serviços disponíveis"
        >
          {SERVICES.map((service) => (
            <ServiceCard key={service.id} service={service} />
          ))}
        </div>
      </div>
    </section>
  );
}
