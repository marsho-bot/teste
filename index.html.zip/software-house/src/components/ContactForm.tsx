"use client";

import React, { useState, useCallback } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { ArrowUpRight, CheckCircle, AlertCircle, Loader2, Mail, User, MessageSquare, Briefcase } from "lucide-react";

// --- Zod schema ---
const contactSchema = z.object({
  name: z
    .string()
    .min(2, "Nome deve ter ao menos 2 caracteres")
    .max(100, "Nome muito longo"),
  email: z
    .string()
    .email("E-mail inválido")
    .max(254, "E-mail muito longo"),
  company: z
    .string()
    .max(100, "Nome da empresa muito longo")
    .optional(),
  projectType: z.enum(
    ["saas", "web", "mobile", "ai", "devops", "api", "design", "security", "other"],
    { required_error: "Selecione o tipo de projeto" }
  ),
  budget: z.enum(["<10k", "10k-50k", "50k-150k", ">150k", "discuss"], {
    required_error: "Selecione o orçamento estimado",
  }),
  message: z
    .string()
    .min(20, "Descreva seu projeto em ao menos 20 caracteres")
    .max(2000, "Mensagem muito longa (máximo 2000 caracteres)"),
});

type ContactFormData = z.infer<typeof contactSchema>;

const PROJECT_TYPES = [
  { value: "saas", label: "SaaS / Plataforma" },
  { value: "web", label: "Web App" },
  { value: "mobile", label: "App Mobile" },
  { value: "ai", label: "AI / LLM" },
  { value: "devops", label: "DevOps / Cloud" },
  { value: "api", label: "API / Backend" },
  { value: "design", label: "Design System" },
  { value: "security", label: "Security" },
  { value: "other", label: "Outro" },
] as const;

const BUDGETS = [
  { value: "<10k", label: "< R$10k" },
  { value: "10k-50k", label: "R$10k – R$50k" },
  { value: "50k-150k", label: "R$50k – R$150k" },
  { value: ">150k", label: "> R$150k" },
  { value: "discuss", label: "Vamos conversar" },
] as const;

// --- Field wrapper ---
interface FieldProps {
  label: string;
  error?: string;
  required?: boolean;
  children: React.ReactNode;
  htmlFor: string;
}

function Field({ label, error, required, children, htmlFor }: FieldProps) {
  return (
    <div className="flex flex-col gap-1.5">
      <label
        htmlFor={htmlFor}
        className="text-sm font-medium text-foreground flex items-center gap-1"
      >
        {label}
        {required && (
          <span className="text-accent text-xs" aria-hidden="true">
            *
          </span>
        )}
      </label>
      {children}
      {error && (
        <p
          className="flex items-center gap-1.5 text-xs text-red-400 animate-fade-in"
          role="alert"
          aria-live="polite"
        >
          <AlertCircle size={12} aria-hidden="true" />
          {error}
        </p>
      )}
    </div>
  );
}

const inputClass = (hasError: boolean) =>
  [
    "w-full px-4 py-3 rounded-xl border bg-surface-2 text-foreground placeholder:text-muted",
    "text-base transition-all duration-200 outline-none",
    "focus:border-accent focus:shadow-accent-sm focus:bg-surface-1",
    hasError ? "border-red-500/60" : "border-border hover:border-border/80",
  ].join(" ");

// --- Success state ---
function SuccessState({ onReset }: { onReset: () => void }) {
  return (
    <div
      className="flex flex-col items-center justify-center gap-6 py-16 text-center animate-fade-up"
      role="status"
      aria-live="polite"
      aria-label="Mensagem enviada com sucesso"
    >
      <div className="relative">
        <div className="w-20 h-20 rounded-full bg-green-500/10 border border-green-500/30 flex items-center justify-center animate-pulse-glow">
          <CheckCircle size={36} className="text-green-400" aria-hidden="true" />
        </div>
        {/* Concentric rings */}
        <div className="absolute inset-0 rounded-full border border-green-500/20 scale-125 animate-ping" aria-hidden="true" />
      </div>
      <div className="flex flex-col gap-2">
        <h3 className="text-xl font-semibold text-foreground">Mensagem enviada!</h3>
        <p className="text-muted text-sm leading-relaxed max-w-xs">
          Recebemos seu contato. Nossa equipe retornará em até 24 horas úteis.
        </p>
      </div>
      <button
        onClick={onReset}
        className="btn-secondary text-sm px-5 py-2.5 min-h-[44px]"
        aria-label="Enviar outra mensagem"
      >
        Enviar outra mensagem
      </button>
    </div>
  );
}

// --- Main form ---
export default function ContactForm() {
  const [submitState, setSubmitState] = useState<"idle" | "loading" | "success" | "error">("idle");

  const {
    register,
    handleSubmit,
    reset,
    watch,
    formState: { errors },
  } = useForm<ContactFormData>({
    resolver: zodResolver(contactSchema),
    mode: "onBlur",
  });

  const messageValue = watch("message", "");

  const onSubmit = useCallback(
    async (data: ContactFormData) => {
      setSubmitState("loading");
      try {
        // Simulate API call — replace with your actual endpoint
        await new Promise<void>((resolve) => setTimeout(resolve, 1800));
        console.log("Form data:", data);
        setSubmitState("success");
      } catch {
        setSubmitState("error");
      }
    },
    []
  );

  const handleReset = useCallback(() => {
    reset();
    setSubmitState("idle");
  }, [reset]);

  return (
    <section
      id="contact"
      className="section-padding relative"
      aria-labelledby="contact-heading"
    >
      {/* Accent glow */}
      <div
        className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[800px] h-[400px] rounded-full"
        style={{
          background:
            "radial-gradient(ellipse, rgba(0,112,243,0.07) 0%, transparent 70%)",
        }}
        aria-hidden="true"
      />

      <div className="container-main relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-start">
          {/* Left: Copy */}
          <div className="flex flex-col gap-6">
            <span className="tag" aria-hidden="true">Contato</span>
            <h2
              id="contact-heading"
              className="text-3xl sm:text-4xl lg:text-5xl font-semibold leading-tight tracking-tight"
            >
              Vamos construir
              <br />
              <span className="text-gradient">algo incrível</span>
            </h2>
            <p className="text-muted text-base leading-relaxed max-w-md">
              Conte sobre seu projeto. Respondemos todos os contatos em até 24h
              com uma análise técnica inicial sem compromisso.
            </p>

            {/* Info cards */}
            <div className="flex flex-col gap-3 mt-2">
              {[
                { icon: Mail, label: "E-mail", value: "hello@nexuslabs.dev" },
                { icon: MessageSquare, label: "Resposta", value: "Em até 24 horas úteis" },
                { icon: Briefcase, label: "NDA", value: "Assinamos NDAs mediante solicitação" },
              ].map((item) => (
                <div
                  key={item.label}
                  className="flex items-center gap-3 p-4 rounded-xl border border-border bg-surface-1"
                >
                  <div
                    className="flex items-center justify-center w-9 h-9 rounded-lg bg-accent/10 border border-accent/20 flex-shrink-0"
                    aria-hidden="true"
                  >
                    <item.icon size={15} className="text-accent" />
                  </div>
                  <div>
                    <p className="text-xs text-muted font-mono">{item.label}</p>
                    <p className="text-sm font-medium text-foreground">{item.value}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: Form */}
          <div className="rounded-2xl border border-border bg-surface-1 overflow-hidden">
            {submitState === "success" ? (
              <SuccessState onReset={handleReset} />
            ) : (
              <form
                onSubmit={handleSubmit(onSubmit)}
                noValidate
                className="p-6 sm:p-8"
                aria-label="Formulário de contato"
              >
                {submitState === "error" && (
                  <div
                    className="flex items-center gap-2.5 p-4 mb-6 rounded-xl bg-red-500/10 border border-red-500/30 text-sm text-red-400 animate-fade-in"
                    role="alert"
                    aria-live="assertive"
                  >
                    <AlertCircle size={15} aria-hidden="true" />
                    <span>Erro ao enviar. Tente novamente ou nos contate por e-mail.</span>
                    <button
                      type="button"
                      onClick={() => setSubmitState("idle")}
                      className="ml-auto text-xs underline min-h-[auto] min-w-[auto] px-1"
                      aria-label="Fechar aviso de erro"
                    >
                      Fechar
                    </button>
                  </div>
                )}

                <div className="flex flex-col gap-5">
                  {/* Row: Name + Company */}
                  <div className="grid sm:grid-cols-2 gap-4">
                    <Field label="Nome" error={errors.name?.message} required htmlFor="name">
                      <div className="relative">
                        <User
                          size={14}
                          className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted pointer-events-none"
                          aria-hidden="true"
                        />
                        <input
                          id="name"
                          type="text"
                          autoComplete="name"
                          placeholder="João Silva"
                          {...register("name")}
                          className={`${inputClass(!!errors.name)} pl-10`}
                          aria-required="true"
                          aria-invalid={!!errors.name}
                          aria-describedby={errors.name ? "name-error" : undefined}
                        />
                      </div>
                    </Field>

                    <Field label="Empresa" error={errors.company?.message} htmlFor="company">
                      <div className="relative">
                        <Briefcase
                          size={14}
                          className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted pointer-events-none"
                          aria-hidden="true"
                        />
                        <input
                          id="company"
                          type="text"
                          autoComplete="organization"
                          placeholder="Acme Corp (opcional)"
                          {...register("company")}
                          className={`${inputClass(!!errors.company)} pl-10`}
                          aria-invalid={!!errors.company}
                        />
                      </div>
                    </Field>
                  </div>

                  {/* Email */}
                  <Field label="E-mail" error={errors.email?.message} required htmlFor="email">
                    <div className="relative">
                      <Mail
                        size={14}
                        className="absolute left-3.5 top-1/2 -translate-y-1/2 text-muted pointer-events-none"
                        aria-hidden="true"
                      />
                      <input
                        id="email"
                        type="email"
                        autoComplete="email"
                        inputMode="email"
                        placeholder="joao@empresa.com"
                        {...register("email")}
                        className={`${inputClass(!!errors.email)} pl-10`}
                        aria-required="true"
                        aria-invalid={!!errors.email}
                      />
                    </div>
                  </Field>

                  {/* Project type */}
                  <Field label="Tipo de Projeto" error={errors.projectType?.message} required htmlFor="projectType">
                    <select
                      id="projectType"
                      {...register("projectType")}
                      className={`${inputClass(!!errors.projectType)} appearance-none cursor-pointer`}
                      aria-required="true"
                      aria-invalid={!!errors.projectType}
                      defaultValue=""
                    >
                      <option value="" disabled>
                        Selecione o tipo...
                      </option>
                      {PROJECT_TYPES.map((t) => (
                        <option key={t.value} value={t.value}>
                          {t.label}
                        </option>
                      ))}
                    </select>
                  </Field>

                  {/* Budget */}
                  <Field label="Orçamento Estimado" error={errors.budget?.message} required htmlFor="budget">
                    <div
                      className="grid grid-cols-2 sm:grid-cols-3 gap-2"
                      role="group"
                      aria-required="true"
                      aria-invalid={!!errors.budget}
                    >
                      {BUDGETS.map((b) => (
                        <label
                          key={b.value}
                          className="relative cursor-pointer"
                        >
                          <input
                            type="radio"
                            value={b.value}
                            {...register("budget")}
                            className="peer sr-only"
                          />
                          <div className="flex items-center justify-center px-3 py-2.5 rounded-xl border border-border bg-surface-2 text-xs font-mono text-muted transition-all duration-150 peer-checked:border-accent peer-checked:bg-accent/10 peer-checked:text-accent hover:border-accent/40 min-h-[44px]">
                            {b.label}
                          </div>
                        </label>
                      ))}
                    </div>
                  </Field>

                  {/* Message */}
                  <Field label="Sobre o Projeto" error={errors.message?.message} required htmlFor="message">
                    <div className="relative">
                      <textarea
                        id="message"
                        rows={4}
                        placeholder="Descreva o problema que quer resolver, o estágio atual e os principais requisitos técnicos..."
                        {...register("message")}
                        className={`${inputClass(!!errors.message)} resize-none`}
                        aria-required="true"
                        aria-invalid={!!errors.message}
                      />
                      <span
                        className="absolute bottom-3 right-3 text-xs font-mono text-muted"
                        aria-live="polite"
                        aria-label={`${messageValue.length} de 2000 caracteres`}
                      >
                        {messageValue.length}/2000
                      </span>
                    </div>
                  </Field>

                  {/* Submit */}
                  <button
                    type="submit"
                    disabled={submitState === "loading"}
                    className="btn-primary w-full py-4 text-base min-h-[52px] disabled:opacity-60 disabled:cursor-not-allowed"
                    aria-label={submitState === "loading" ? "Enviando mensagem..." : "Enviar mensagem"}
                  >
                    {submitState === "loading" ? (
                      <>
                        <Loader2 size={16} className="animate-spin" aria-hidden="true" />
                        Enviando...
                      </>
                    ) : (
                      <>
                        Enviar Mensagem
                        <ArrowUpRight size={16} aria-hidden="true" />
                      </>
                    )}
                  </button>

                  <p className="text-center text-xs text-muted">
                    Ao enviar, você concorda com nossa{" "}
                    <a
                      href="/privacy"
                      className="text-accent hover:underline focus-visible:outline-accent min-h-[auto] min-w-[auto]"
                    >
                      Política de Privacidade
                    </a>
                    .
                  </p>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
