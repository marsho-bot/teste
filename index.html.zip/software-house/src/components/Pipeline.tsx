"use client";

import React, { useState, useCallback, useRef, useEffect } from "react";
import {
  Lightbulb,
  Layout,
  Code2,
  FlaskConical,
  Rocket,
  BarChart2,
  ArrowRight,
} from "lucide-react";

interface PipelineStep {
  id: number;
  phase: string;
  title: string;
  description: string;
  icon: React.ElementType;
  duration: string;
  deliverables: string[];
  color: string;
}

const PIPELINE_STEPS: PipelineStep[] = [
  {
    id: 1,
    phase: "01",
    title: "Discovery",
    description:
      "Mapeamos requisitos, usuários e restrições técnicas. Definimos OKRs mensuráveis e arquitetura de solução.",
    icon: Lightbulb,
    duration: "1-2 semanas",
    deliverables: ["Tech Brief", "Arquitetura", "Roadmap"],
    color: "#0070f3",
  },
  {
    id: 2,
    phase: "02",
    title: "Design",
    description:
      "Design System, protótipos interativos e validação com usuários reais. Zero surpresa na implementação.",
    icon: Layout,
    duration: "1-3 semanas",
    deliverables: ["Design System", "Protótipos", "User Tests"],
    color: "#7c3aed",
  },
  {
    id: 3,
    phase: "03",
    title: "Engineering",
    description:
      "Sprints de 2 semanas, code reviews rigorosos, testes automatizados e CI/CD desde o dia 1.",
    icon: Code2,
    duration: "4-12 semanas",
    deliverables: ["Código", "CI/CD", "Docs"],
    color: "#d97706",
  },
  {
    id: 4,
    phase: "04",
    title: "QA & Testing",
    description:
      "Testes E2E, performance, segurança e acessibilidade. 90%+ de cobertura antes de qualquer release.",
    icon: FlaskConical,
    duration: "1-2 semanas",
    deliverables: ["E2E Tests", "Audit", "Lighthouse 100"],
    color: "#059669",
  },
  {
    id: 5,
    phase: "05",
    title: "Deploy",
    description:
      "Blue-green deployment, rollback instantâneo, monitoramento em tempo real. Zero downtime garantido.",
    icon: Rocket,
    duration: "1-3 dias",
    deliverables: ["Production", "Monitoring", "Alertas"],
    color: "#dc2626",
  },
  {
    id: 6,
    phase: "06",
    title: "Growth",
    description:
      "Analytics, A/B tests, otimizações contínuas. Medimos impacto real e iteramos com dados.",
    icon: BarChart2,
    duration: "Contínuo",
    deliverables: ["Analytics", "A/B Tests", "Relatórios"],
    color: "#0891b2",
  },
];

export default function Pipeline() {
  const [activeStep, setActiveStep] = useState<number>(1);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const scrollRef = useRef<HTMLDivElement>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const goToStep = useCallback((id: number) => {
    setActiveStep(id);
    setIsAutoPlaying(false);
  }, []);

  // Auto-advance
  useEffect(() => {
    if (!isAutoPlaying) return;
    intervalRef.current = setInterval(() => {
      setActiveStep((prev) => (prev >= PIPELINE_STEPS.length ? 1 : prev + 1));
    }, 3000);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isAutoPlaying]);

  // Scroll active step into view on mobile
  useEffect(() => {
    if (!scrollRef.current) return;
    const el = scrollRef.current.querySelector(`[data-step="${activeStep}"]`);
    if (el) {
      el.scrollIntoView({ behavior: "smooth", block: "nearest", inline: "center" });
    }
  }, [activeStep]);

  const activeData = PIPELINE_STEPS.find((s) => s.id === activeStep)!;
  const ActiveIcon = activeData.icon;

  return (
    <section
      id="pipeline"
      className="section-padding relative overflow-hidden"
      aria-labelledby="pipeline-heading"
    >
      {/* Background */}
      <div
        className="absolute inset-0 opacity-40"
        style={{
          background:
            "linear-gradient(180deg, transparent 0%, rgba(0,112,243,0.03) 50%, transparent 100%)",
        }}
        aria-hidden="true"
      />

      <div className="container-main relative z-10">
        {/* Header */}
        <div className="flex flex-col gap-3 mb-12">
          <span className="tag" aria-hidden="true">Pipeline</span>
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <h2
              id="pipeline-heading"
              className="text-3xl sm:text-4xl lg:text-5xl font-semibold leading-tight tracking-tight"
            >
              Como{" "}
              <span className="text-gradient">entregamos</span>
            </h2>
            <p className="text-muted text-sm max-w-xs sm:text-right leading-relaxed">
              Processo estruturado, prazos reais e comunicação contínua.
            </p>
          </div>
        </div>

        {/* Steps nav — horizontal scrollable */}
        <div
          ref={scrollRef}
          className="flex gap-2 overflow-x-auto pb-4 mb-8 scrollbar-none"
          role="tablist"
          aria-label="Etapas do pipeline"
          style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
        >
          {PIPELINE_STEPS.map((step, i) => {
            const Icon = step.icon;
            const isActive = step.id === activeStep;
            return (
              <React.Fragment key={step.id}>
                <button
                  data-step={step.id}
                  role="tab"
                  aria-selected={isActive}
                  aria-controls={`panel-${step.id}`}
                  onClick={() => goToStep(step.id)}
                  className={[
                    "flex-shrink-0 flex items-center gap-2.5 px-4 py-3 rounded-xl border text-sm font-medium transition-all duration-200 min-h-[44px] whitespace-nowrap",
                    isActive
                      ? "border-[var(--step-color)] bg-[var(--step-bg)] text-foreground shadow-[0_0_20px_var(--step-shadow)]"
                      : "border-border bg-surface-1 text-muted hover:border-border/80 hover:text-foreground",
                  ].join(" ")}
                  style={
                    {
                      "--step-color": step.color,
                      "--step-bg": `${step.color}15`,
                      "--step-shadow": `${step.color}30`,
                    } as React.CSSProperties
                  }
                  aria-label={`Etapa ${step.phase}: ${step.title}`}
                >
                  <Icon size={14} style={{ color: isActive ? step.color : undefined }} aria-hidden="true" />
                  <span>{step.title}</span>
                </button>
                {i < PIPELINE_STEPS.length - 1 && (
                  <div className="flex-shrink-0 flex items-center" aria-hidden="true">
                    <ArrowRight size={12} className="text-border" />
                  </div>
                )}
              </React.Fragment>
            );
          })}
        </div>

        {/* Active step detail card */}
        <div
          id={`panel-${activeData.id}`}
          role="tabpanel"
          aria-label={`Detalhes: ${activeData.title}`}
          className="grid md:grid-cols-3 gap-6"
          key={activeStep}
        >
          {/* Main info */}
          <div
            className="md:col-span-2 rounded-2xl border p-6 sm:p-8 transition-all duration-300 animate-fade-in"
            style={{
              borderColor: `${activeData.color}30`,
              background: `${activeData.color}06`,
            }}
          >
            <div className="flex items-start gap-4 mb-5">
              <div
                className="flex items-center justify-center w-12 h-12 rounded-xl border flex-shrink-0"
                style={{
                  backgroundColor: `${activeData.color}15`,
                  borderColor: `${activeData.color}30`,
                }}
                aria-hidden="true"
              >
                <ActiveIcon size={20} style={{ color: activeData.color }} />
              </div>
              <div>
                <div
                  className="text-xs font-mono font-medium mb-1"
                  style={{ color: activeData.color }}
                  aria-hidden="true"
                >
                  Fase {activeData.phase}
                </div>
                <h3 className="text-xl sm:text-2xl font-semibold">{activeData.title}</h3>
              </div>
            </div>
            <p className="text-muted leading-relaxed text-base">{activeData.description}</p>

            {/* Progress dots */}
            <div className="flex gap-2 mt-6" role="presentation" aria-hidden="true">
              {PIPELINE_STEPS.map((s) => (
                <div
                  key={s.id}
                  className="h-1 rounded-full transition-all duration-300"
                  style={{
                    width: s.id === activeStep ? "24px" : "6px",
                    backgroundColor:
                      s.id === activeStep
                        ? activeData.color
                        : s.id < activeStep
                        ? `${activeData.color}40`
                        : "#1a1a1a",
                  }}
                />
              ))}
            </div>
          </div>

          {/* Meta sidebar */}
          <div className="flex flex-col gap-4">
            {/* Duration */}
            <div className="rounded-2xl border border-border bg-surface-1 p-5">
              <p className="text-xs font-mono text-muted uppercase tracking-widest mb-2">
                Duração estimada
              </p>
              <p
                className="text-2xl font-mono font-semibold"
                style={{ color: activeData.color }}
              >
                {activeData.duration}
              </p>
            </div>

            {/* Deliverables */}
            <div className="rounded-2xl border border-border bg-surface-1 p-5 flex-1">
              <p className="text-xs font-mono text-muted uppercase tracking-widest mb-3">
                Entregáveis
              </p>
              <ul className="flex flex-col gap-2" role="list">
                {activeData.deliverables.map((d) => (
                  <li
                    key={d}
                    className="flex items-center gap-2 text-sm font-mono text-foreground"
                    role="listitem"
                  >
                    <div
                      className="w-1.5 h-1.5 rounded-full flex-shrink-0"
                      style={{ backgroundColor: activeData.color }}
                      aria-hidden="true"
                    />
                    {d}
                  </li>
                ))}
              </ul>
            </div>

            {/* Auto-play toggle */}
            <button
              onClick={() => setIsAutoPlaying((p) => !p)}
              className="w-full py-3 rounded-xl border border-border bg-surface-1 text-sm text-muted hover:text-foreground hover:border-accent/40 transition-all duration-200 font-mono min-h-[44px]"
              aria-pressed={isAutoPlaying}
              aria-label={isAutoPlaying ? "Pausar auto-play" : "Iniciar auto-play"}
            >
              {isAutoPlaying ? "⏸ Pausar" : "▶ Auto-play"}
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
