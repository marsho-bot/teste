"use client";

import React, { useState, useEffect, useCallback, useRef } from "react";
import { Menu, X, Terminal, ArrowUpRight } from "lucide-react";

interface NavItem {
  label: string;
  href: string;
}

const NAV_ITEMS: NavItem[] = [
  { label: "Serviços", href: "#services" },
  { label: "Pipeline", href: "#pipeline" },
  { label: "Stack", href: "#stack" },
  { label: "Sobre", href: "#about" },
];

export default function Header() {
  const [isVisible, setIsVisible] = useState(true);
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileOpen, setIsMobileOpen] = useState(false);
  const lastScrollY = useRef(0);
  const ticking = useRef(false);
  const mobileMenuRef = useRef<HTMLDivElement>(null);

  const handleScroll = useCallback(() => {
    if (!ticking.current) {
      window.requestAnimationFrame(() => {
        const currentScrollY = window.scrollY;
        setIsScrolled(currentScrollY > 20);

        if (currentScrollY < 80) {
          setIsVisible(true);
        } else if (currentScrollY < lastScrollY.current) {
          setIsVisible(true);
        } else if (currentScrollY > lastScrollY.current + 5) {
          setIsVisible(false);
          setIsMobileOpen(false);
        }

        lastScrollY.current = currentScrollY;
        ticking.current = false;
      });
      ticking.current = true;
    }
  }, []);

  useEffect(() => {
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, [handleScroll]);

  // Body lock on mobile menu open
  useEffect(() => {
    if (isMobileOpen) {
      document.body.style.overflow = "hidden";
      document.body.style.position = "fixed";
      document.body.style.width = "100%";
    } else {
      document.body.style.overflow = "";
      document.body.style.position = "";
      document.body.style.width = "";
    }
    return () => {
      document.body.style.overflow = "";
      document.body.style.position = "";
      document.body.style.width = "";
    };
  }, [isMobileOpen]);

  // Close on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (
        mobileMenuRef.current &&
        !mobileMenuRef.current.contains(e.target as Node)
      ) {
        setIsMobileOpen(false);
      }
    };
    if (isMobileOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [isMobileOpen]);

  const handleNavClick = useCallback(
    (href: string) => {
      setIsMobileOpen(false);
      const el = document.querySelector(href);
      if (el) {
        setTimeout(() => {
          el.scrollIntoView({ behavior: "smooth", block: "start" });
        }, 50);
      }
    },
    []
  );

  const toggleMobile = useCallback(() => {
    setIsMobileOpen((prev) => !prev);
  }, []);

  return (
    <>
      <header
        role="banner"
        className={[
          "fixed top-0 left-0 right-0 z-50 transition-all duration-300 ease-in-out",
          isVisible ? "translate-y-0" : "-translate-y-full",
          isScrolled
            ? "bg-background/90 backdrop-blur-xl border-b border-border shadow-glow-white"
            : "bg-transparent",
        ].join(" ")}
        aria-label="Navegação principal"
      >
        <div className="container-main">
          <div className="flex items-center justify-between h-16 md:h-20">
            {/* Logo */}
            <a
              href="/"
              className="flex items-center gap-2.5 group min-h-[44px] min-w-[44px] !justify-start"
              aria-label="Nexus Labs - Página inicial"
            >
              <div
                className="flex items-center justify-center w-8 h-8 rounded-lg bg-accent/10 border border-accent/30 group-hover:bg-accent/20 group-hover:border-accent/60 transition-all duration-200"
                aria-hidden="true"
              >
                <Terminal size={16} className="text-accent" />
              </div>
              <span className="font-mono text-sm font-semibold tracking-tight">
                <span className="text-foreground">nexus</span>
                <span className="text-accent">.</span>
                <span className="text-muted">labs</span>
              </span>
            </a>

            {/* Desktop Nav */}
            <nav
              aria-label="Menu principal"
              className="hidden md:flex items-center gap-1"
            >
              {NAV_ITEMS.map((item) => (
                <button
                  key={item.href}
                  onClick={() => handleNavClick(item.href)}
                  className="px-4 py-2 text-sm text-muted hover:text-foreground transition-colors duration-200 rounded-lg hover:bg-surface-1 min-h-[44px] font-medium"
                  aria-label={`Ir para seção ${item.label}`}
                >
                  {item.label}
                </button>
              ))}
            </nav>

            {/* Desktop CTA */}
            <div className="hidden md:flex items-center gap-3">
              <a
                href="#contact"
                className="btn-primary text-sm px-5 py-2.5 min-h-[44px]"
                aria-label="Iniciar projeto com Nexus Labs"
              >
                <span>Iniciar Projeto</span>
                <ArrowUpRight size={14} aria-hidden="true" />
              </a>
            </div>

            {/* Mobile toggle */}
            <button
              onClick={toggleMobile}
              className="md:hidden flex items-center justify-center w-11 h-11 rounded-xl border border-border hover:border-accent/40 hover:bg-surface-1 transition-all duration-200"
              aria-label={isMobileOpen ? "Fechar menu" : "Abrir menu"}
              aria-expanded={isMobileOpen}
              aria-controls="mobile-menu"
            >
              {isMobileOpen ? (
                <X size={18} aria-hidden="true" />
              ) : (
                <Menu size={18} aria-hidden="true" />
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      <div
        id="mobile-menu"
        role="dialog"
        aria-modal="true"
        aria-label="Menu mobile"
        className={[
          "fixed inset-0 z-40 md:hidden transition-all duration-300 ease-in-out",
          isMobileOpen
            ? "opacity-100 pointer-events-auto"
            : "opacity-0 pointer-events-none",
        ].join(" ")}
      >
        {/* Backdrop */}
        <div
          className="absolute inset-0 bg-background/80 backdrop-blur-sm"
          aria-hidden="true"
        />

        {/* Panel */}
        <div
          ref={mobileMenuRef}
          className={[
            "absolute top-0 right-0 h-full w-80 max-w-[90vw] bg-surface-1 border-l border-border transition-transform duration-300 ease-in-out",
            isMobileOpen ? "translate-x-0" : "translate-x-full",
          ].join(" ")}
        >
          <div className="flex flex-col h-full p-6 pt-20">
            <nav
              aria-label="Menu mobile"
              className="flex flex-col gap-2 flex-1"
            >
              {NAV_ITEMS.map((item, i) => (
                <button
                  key={item.href}
                  onClick={() => handleNavClick(item.href)}
                  className={[
                    "flex items-center justify-between w-full px-4 py-3.5 rounded-xl text-left text-base font-medium transition-all duration-200",
                    "text-muted hover:text-foreground hover:bg-surface-2 border border-transparent hover:border-border",
                    isMobileOpen
                      ? "opacity-100 translate-x-0"
                      : "opacity-0 translate-x-4",
                  ].join(" ")}
                  style={{
                    transitionDelay: isMobileOpen ? `${i * 60}ms` : "0ms",
                  }}
                  aria-label={`Ir para seção ${item.label}`}
                >
                  <span>{item.label}</span>
                  <ArrowUpRight size={14} aria-hidden="true" />
                </button>
              ))}
            </nav>

            <div
              className={[
                "mt-auto transition-all duration-300",
                isMobileOpen
                  ? "opacity-100 translate-y-0"
                  : "opacity-0 translate-y-4",
              ].join(" ")}
              style={{ transitionDelay: isMobileOpen ? "280ms" : "0ms" }}
            >
              <a
                href="#contact"
                onClick={() => setIsMobileOpen(false)}
                className="btn-primary w-full text-base py-4 min-h-[52px]"
                aria-label="Iniciar projeto"
              >
                <span>Iniciar Projeto</span>
                <ArrowUpRight size={16} aria-hidden="true" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
