"use client";

import React, { useState, useEffect, useCallback, useMemo } from "react";
import { ArrowUpRight, ChevronDown, Circle } from "lucide-react";

// --- Terminal Deploy Simulation ---
interface TerminalLine {
  id: number;
  type: "cmd" | "out" | "success" | "warn" | "info";
  text: string;
  delay: number;
}

const DEPLOY_SEQUENCE: TerminalLine[] = [
  { id: 1, type: "cmd", text: "$ git push nexus main", delay: 0 },
  { id: 2, type: "out", text: "→ Compressing objects... 100%", delay: 700 },
  { id: 3, type: "out", text: "→ Writing objects: 100% (47/47)", delay: 1300 },
  { id: 4, type: "info", text: "✦ Build triggered [#a3f91c]", delay: 1900 },
  { id: 5, type: "out", text: "→ Running type-check (strict)", delay: 2500 },
  { id: 6, type: "success", text: "✓ TypeScript: 0 errors", delay: 3200 },
  { id: 7, type: "out", text: "→ Running tests (148 suites)", delay: 3800 },
  { id: 8, type: "success", text: "✓ All tests passed (1.2s)", delay: 4700 },
  { id: 9, type: "out", text: "→ Building production bundle...", delay: 5300 },
  { id: 10, type: "out", text: "→ Optimizing images & assets", delay: 5900 },
  { id: 11, type: "success", text: "✓ Bundle: 47kB gzip", delay: 6800 },
  { id: 12, type: "info", text: "→ Deploying to edge (32 regions)", delay: 7400 },
  { id: 13, type: "success", text: "✓ LIVE → nexus.app/v2.4.1", delay: 8500 },
  { id: 14, type: "cmd", text: "$ _", delay: 9200 },
];

const LINE_COLORS: Record<TerminalLine["type"], string> = {
  cmd: "text-foreground font-medium",
  out: "text-muted",
  success: "text-green-400",
  warn: "text-yellow-400",
  info: "text-accent",
};

function TerminalDeploy() {
  const [visibleLines, setVisibleLines] = useState<number[]>([]);
  const [isRunning, setIsRunning] = useState(true);

  const startSequence = useCallback(() => {
    setVisibleLines([]);
    setIsRunning(true);
    const timers: ReturnType<typeof setTimeout>[] = [];

    DEPLOY_SEQUENCE.forEach((line) => {
      const t = setTimeout(() => {
        setVisibleLines((prev) => [...prev, line.id]);
      }, line.delay);
      timers.push(t);
    });

    const finish = setTimeout(() => {
      setIsRunning(false);
    }, 10500);
    timers.push(finish);

    return () => timers.forEach(clearTimeout);
  }, []);

  useEffect(() => {
    const cleanup = startSequence();
    return cleanup;
  }, [startSequence]);

  const handleRestart = useCallback(() => {
    startSequence();
  }, [startSequence]);

  return (
    <div className="terminal-window w-full max-w-[560px]" role="region" aria-label="Terminal de deploy ao vivo">
      {/* Header */}
      <div className="terminal-header">
        <div className="terminal-dot bg-red-500" aria-hidden="true" />
        <div className="terminal-dot bg-yellow-500" aria-hidden="true" />
        <div className="terminal-dot bg-green-500" aria-hidden="true" />
        <span className="ml-3 text-xs font-mono text-muted flex-1">
          nexus-deploy — production
        </span>
        <button
          onClick={handleRestart}
          disabled={isRunning}
          className="text-xs font-mono text-muted hover:text-foreground transition-colors min-h-[auto] min-w-[auto] px-2 py-0.5 disabled:opacity-40 disabled:cursor-not-allowed rounded"
          aria-label="Reiniciar simulação de deploy"
        >
          {isRunning ? "running..." : "↺ restart"}
        </button>
        <div className="flex items-center gap-1.5 ml-3">
          <div className={`glow-dot ${isRunning ? "animate-pulse" : ""}`} aria-hidden="true" />
          <span className="text-xs font-mono text-green-400">
            {isRunning ? "deploying" : "live"}
          </span>
        </div>
      </div>

      {/* Body */}
      <div
        className="p-5 min-h-[280px] font-mono text-sm leading-relaxed overflow-hidden"
        aria-live="polite"
        aria-label="Output do terminal"
      >
        {DEPLOY_SEQUENCE.map((line) =>
          visibleLines.includes(line.id) ? (
            <div
              key={line.id}
              className={`${LINE_COLORS[line.type]} mb-1 animate-fade-in`}
              role="log"
            >
              {line.id === 14 && isRunning === false ? (
                <>
                  <span>$ </span>
                  <span className="inline-block w-2 h-4 bg-foreground align-middle animate-cursor-blink" aria-hidden="true" />
                </>
              ) : (
                line.text
              )}
            </div>
          ) : null
        )}
      </div>

      {/* Footer */}
      <div className="px-5 py-3 border-t border-border flex items-center justify-between">
        <span className="text-xs font-mono text-muted">
          nexus-cli v3.2.1
        </span>
        <div className="flex items-center gap-3 text-xs font-mono text-muted">
          <span>Lighthouse: <span className="text-green-400 font-medium">100</span></span>
          <span>•</span>
          <span>Uptime: <span className="text-green-400 font-medium">99.99%</span></span>
        </div>
      </div>
    </div>
  );
}

// --- Stats ---
const STATS = [
  { value: "200+", label: "Projetos entregues" },
  { value: "99.9%", label: "Uptime garantido" },
  { value: "40+", label: "Tecnologias dominadas" },
  { value: "12", label: "Países atendidos" },
];

// --- Hero Component ---
export default function Hero() {
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  const handleMouseMove = useCallback((e: React.MouseEvent) => {
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    setMousePos({
      x: ((e.clientX - rect.left) / rect.width) * 100,
      y: ((e.clientY - rect.top) / rect.height) * 100,
    });
  }, []);

  const radialStyle = useMemo(
    () => ({
      background: `radial-gradient(800px at ${mousePos.x}% ${mousePos.y}%, rgba(0,112,243,0.08) 0%, transparent 70%)`,
    }),
    [mousePos.x, mousePos.y]
  );

  return (
    <section
      id="hero"
      className="relative min-h-screen flex flex-col justify-center overflow-hidden pt-20"
      onMouseMove={handleMouseMove}
      aria-label="Seção principal - Hero"
    >
      {/* Background layers */}
      <div className="absolute inset-0 bg-grid-pattern bg-grid animate-grid-flow opacity-30" aria-hidden="true" />
      <div className="absolute inset-0 transition-all duration-200" style={radialStyle} aria-hidden="true" />
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-transparent to-background" aria-hidden="true" />

      {/* Glow orbs */}
      <div
        className="absolute top-1/4 left-1/2 -translate-x-1/2 w-[600px] h-[600px] rounded-full"
        style={{ background: "radial-gradient(circle, rgba(0,112,243,0.08) 0%, transparent 70%)" }}
        aria-hidden="true"
      />

      <div className="container-main relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-8 items-center">
          {/* Left column — Copy */}
          <div className="flex flex-col gap-6">
            {/* Badge */}
            <div className="animate-fade-up opacity-0" style={{ animationDelay: "0ms", animationFillMode: "forwards" }}>
              <span className="tag" role="text">
                <Circle size={6} className="fill-green-400 text-green-400 animate-pulse" aria-hidden="true" />
                Disponível para novos projetos
              </span>
            </div>

            {/* Headline */}
            <div className="animate-fade-up opacity-0" style={{ animationDelay: "100ms", animationFillMode: "forwards" }}>
              <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-semibold leading-[1.05] tracking-tight">
                <span className="text-foreground">Engenharia de</span>
                <br />
                <span className="text-foreground">Software de</span>
                <br />
                <span className="text-gradient">Elite</span>
                <span className="text-muted"> para o</span>
                <br />
                <span className="text-muted">Mercado Global</span>
              </h1>
            </div>

            {/* Description */}
            <div className="animate-fade-up opacity-0" style={{ animationDelay: "200ms", animationFillMode: "forwards" }}>
              <p className="text-base sm:text-lg text-muted leading-relaxed max-w-xl">
                Construímos produtos digitais de alta performance que escalam globalmente.
                Do conceito ao deploy — arquitetura sólida, código limpo, zero compromissos.
              </p>
            </div>

            {/* CTAs */}
            <div
              className="flex flex-wrap gap-3 animate-fade-up opacity-0"
              style={{ animationDelay: "300ms", animationFillMode: "forwards" }}
            >
              <a
                href="#contact"
                className="btn-primary px-6 py-3.5 text-base min-h-[52px]"
                aria-label="Iniciar projeto com Nexus Labs"
              >
                Iniciar Projeto
                <ArrowUpRight size={16} aria-hidden="true" />
              </a>
              <a
                href="#services"
                className="btn-secondary px-6 py-3.5 text-base min-h-[52px]"
                aria-label="Ver serviços oferecidos"
              >
                Ver Serviços
              </a>
            </div>

            {/* Stats */}
            <div
              className="grid grid-cols-2 sm:grid-cols-4 gap-4 pt-4 border-t border-border animate-fade-up opacity-0"
              style={{ animationDelay: "400ms", animationFillMode: "forwards" }}
              role="list"
              aria-label="Estatísticas"
            >
              {STATS.map((stat) => (
                <div key={stat.label} className="flex flex-col gap-0.5" role="listitem">
                  <span className="text-xl sm:text-2xl font-semibold font-mono text-foreground">
                    {stat.value}
                  </span>
                  <span className="text-xs text-muted leading-tight">{stat.label}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Right column — Terminal */}
          <div
            className="flex justify-center lg:justify-end animate-fade-up opacity-0"
            style={{ animationDelay: "200ms", animationFillMode: "forwards" }}
          >
            <TerminalDeploy />
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 animate-pulse" aria-hidden="true">
        <span className="text-xs font-mono text-muted uppercase tracking-widest">Scroll</span>
        <ChevronDown size={14} className="text-muted" />
      </div>
    </section>
  );
}
