import type { Metadata, Viewport } from "next";
import { GeistSans } from "geist/font/sans";
import { GeistMono } from "geist/font/mono";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "Nexus Labs — Engenharia de Software de Elite",
    template: "%s | Nexus Labs",
  },
  description:
    "Construímos produtos digitais de alta performance para o mercado global. SaaS, Web, Mobile, AI, DevOps, APIs e Security.",
  keywords: [
    "software house",
    "engenharia de software",
    "desenvolvimento web",
    "next.js",
    "typescript",
    "saas",
    "mobile",
    "ai",
    "devops",
  ],
  authors: [{ name: "Nexus Labs" }],
  creator: "Nexus Labs",
  openGraph: {
    type: "website",
    locale: "pt_BR",
    url: "https://nexuslabs.dev",
    siteName: "Nexus Labs",
    title: "Nexus Labs — Engenharia de Software de Elite",
    description:
      "Construímos produtos digitais de alta performance para o mercado global.",
    images: [
      {
        url: "https://images.unsplash.com/photo-1451187580459-43490279c0fa?w=1200&h=630&fit=crop",
        width: 1200,
        height: 630,
        alt: "Nexus Labs — Software Engineering",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "Nexus Labs — Engenharia de Software de Elite",
    description:
      "Construímos produtos digitais de alta performance para o mercado global.",
    creator: "@nexuslabs",
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-video-preview": -1,
      "max-image-preview": "large",
      "max-snippet": -1,
    },
  },
  icons: {
    icon: "/favicon.ico",
    shortcut: "/favicon-16x16.png",
    apple: "/apple-touch-icon.png",
  },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1, // Prevents iOS auto-zoom on inputs
  userScalable: false,
  themeColor: [{ media: "(prefers-color-scheme: dark)", color: "#050505" }],
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="pt-BR"
      className={`${GeistSans.variable} ${GeistMono.variable}`}
      suppressHydrationWarning
    >
      <body className="bg-background text-foreground font-sans antialiased overflow-x-hidden">
        <div id="root" className="relative min-h-screen">
          {children}
        </div>
      </body>
    </html>
  );
}
