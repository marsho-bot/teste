import type { Metadata } from "next";
import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Services from "@/components/Services";
import Pipeline from "@/components/Pipeline";
import TechStack from "@/components/TechStack";
import ContactForm from "@/components/ContactForm";
import Footer from "@/components/Footer";

export const metadata: Metadata = {
  title: "Nexus Labs — Engenharia de Software de Elite para o Mercado Global",
  description:
    "Software House especializada em SaaS, Web Apps, Mobile, AI, DevOps, APIs, Design Systems e Security. Performance 100/100 no Lighthouse, arquitetura sólida e zero compromissos.",
};

export default function HomePage() {
  return (
    <>
      {/* Skip to main content - accessibility */}
      <a
        href="#main-content"
        className="sr-only focus:not-sr-only focus:fixed focus:top-4 focus:left-4 focus:z-[100] btn-primary text-sm px-4 py-2"
        aria-label="Ir para o conteúdo principal"
      >
        Pular para o conteúdo
      </a>

      <Header />

      <main id="main-content" tabIndex={-1} aria-label="Conteúdo principal">
        {/* 1. Hero */}
        <Hero />

        {/* 2. Services — Bento Grid */}
        <Services />

        {/* 3. Pipeline — Interactive steps */}
        <Pipeline />

        {/* 4. Tech Stack — Floating parallax cloud */}
        <TechStack />

        {/* 5. Contact Form */}
        <ContactForm />
      </main>

      <Footer />
    </>
  );
}
